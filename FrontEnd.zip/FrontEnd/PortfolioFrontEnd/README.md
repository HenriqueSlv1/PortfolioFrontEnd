# projeto-portfolio

A disciplina de Front-End se apresentou como uma chance imperdível de mergulhar mais fundo no mundo do desenvolvimento web. Foi nesse cenário que meu projeto de portfólio tomou forma, atuando como uma tela em branco onde poderia experimentar e aplicar os conceitos que estava aprendendo.
O projeto me levou a explorar o HTML de uma forma mais profunda. Cada elemento, tag e atributo adquiriu um significado mais amplo à medida que os aplicava para criar uma base sólida para meu portfólio. Aprendi a organizar meu conteúdo de forma lógica e semântica, tornando-o acessível e compreensível para os visitantes do site.
